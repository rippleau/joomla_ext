<?php
defined('_JEXEC') or die('');
/*
* featured/Latest/Topten/Random Products Module
*
* @version $Id: mod_vm_product.php 2789 2011-02-28 12:41:01Z oscar $
* @package VirtueMart
* @subpackage modules
*
* @copyright (C) 2010 - Patrick Kohl
* @copyright (C) 2017 - Studio42
* @author Patrick Kohl
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* www.st42.fr
*/


defined('DS') or define('DS', DIRECTORY_SEPARATOR);
if (!class_exists( 'VmConfig' )) require(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_virtuemart'.DS.'helpers'.DS.'config.php');

VmConfig::loadConfig();
VmConfig::loadJLang('mod_vm_product', true);

// Setting
$max_items = 		$params->get( 'max_items', 2 ); //maximum number of items to display
$products_per_row = $params->get( 'products_per_row', 1 ); // Display X products per Row
$show_price = 		(bool)$params->get( 'show_price', 1 ); // Display the Product Price?
$show_addtocart = 	(bool)$params->get( 'show_addtocart', 1 ); // Display the "Add-to-Cart" Link?
$ids = $params->get( 'product_id', null );
// check if we have valid ids
if(empty($ids)) return false;
$ids = explode(",", $ids);
JArrayHelper::toInteger($ids);
// $mainframe = Jfactory::getApplication();
//$virtuemart_currency_id = $mainframe->getUserStateFromRequest( "virtuemart_currency_id", 'virtuemart_currency_id',vRequest::getInt('virtuemart_currency_id',0) );

if ($show_addtocart) {
	vmJsApi::jPrice();
	vmJsApi::cssSite();
	echo vmJsApi::writeJS();
}


$productModel = VmModel::getModel('Product');
$products = $productModel->getProducts ($ids); // getProduct($id), for one product
$productModel->addImages($products);

if (!class_exists('shopFunctionsF')) require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
shopFunctionsF::sortLoadProductCustomsStockInd($products,$productModel);

$totalProd =  count( $products);
if(empty($products)) return false;

if (!class_exists('CurrencyDisplay')) require(VMPATH_ADMIN . DS . 'helpers' . DS . 'currencydisplay.php');
$currency = CurrencyDisplay::getInstance();


/* Load tmpl default */
require JModuleHelper::getLayoutPath('mod_vm_product', $params->get('layout', 'default')); 

echo vmJsApi::writeJS();
?>
