<?php
/*
				MySQL DB backup class, version 3.2.2
				LazyDbBackup - (Original : LazyBackup)
				* &licence GNU/GPL 
*/
defined('_JEXEC') or die('Restricted access');
define('MSX_VERSION', '3.2.2');
define('MSX_NL', "\n");
define('MSX_STRING', 0);
define('MSX_DOWNLOAD', 1);
define('MSX_SAVE', 2);
define('MSX_APPEND', 3);


class LazyDbBackup_MySQL_DB_Backup
{
	var $server = 'localhost';
	var $port = 3306;
	var $username = 'root';
	var $password = '';
	var $database = '';
	var $link_id = -1;
	var $connected = false;
	var $tables = array();
	var $create_tables = true;
	var $drop_tables = true;
	var $struct_only = 0;
	var $site_only = true;
	var $foreign_key = 1;
	var $locks = true;
	var $comments = true;
	var $backup_dir = '';
	var $fname_format = 'd_m_y__H_i_s';
	var $error = '';
	var $null_values = array( '0000-00-00', '00:00:00', '0000-00-00 00:00:00');
	var $lazydbbackup_file_name = '';
	var $dbtype = 'mysql';

	function Execute($task = MSX_STRING, $dname = '', $compress = false)
	{
		$fp = false;
		if ($task == MSX_APPEND || $task == MSX_SAVE || $task == MSX_DOWNLOAD)
		{
			$tmp_name = $dname;
			if (empty($tmp_name) || $task == MSX_DOWNLOAD)
			{
				$tmp_name = date($this->fname_format);
				$tmp_name .= ($compress ? '.sql.gz' : '.sql');
				if (empty($dname))				
				{
					$dname = $tmp_name;
				}
			}
			$fname = $this->backup_dir.$tmp_name;
			$this->lazydbbackup_file_name=$fname;
			if (!($fp = $this->_OpenFile($fname, $task, $compress)))
			{
				return false;
			}
		}
		if (!($sql = $this->_Retrieve($fp, $compress)))
		{
			return false;
		}

		if ($task == MSX_DOWNLOAD)
		{
			$this->_CloseFile($fp, $compress);
			return $this->_DownloadFile($fname, $dname);
		}
		else if ($task == MSX_APPEND || $task == MSX_SAVE)
		{
			$this->_CloseFile($fp, $compress);
			return true;
		}
		else
		{
			return $sql;
		}
	}


	private function Connect($host,$username,$password)
	{

			try {
				$this->handler = new PDO($host, $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''));
				$value = true;
			} catch (PDOException $e) {
				$this->handler = null;
				$this->error[] = $e->getMessage();
				return false;
			}
		return $value;
	}

	function _GetTables($lb_prefix)
	{
        try {
            $stmt = $this->handler->query('SHOW TABLES');
            $tbs = $stmt->fetchAll();
            $i=0;
 			$site_only =$this->site_only;
			$config = JFactory::getConfig();
			$lb_prefix     = $config->get('dbprefix');	
			$value = array();	
          foreach($tbs as $table){
				if ($site_only == 0) {
					$value[] = $table[0];
					/*$this->tables[$i]['name'] = $table[0];
					$this->tables[$i]['create'] = $this->getColumns($table[0]);
					$this->tables[$i]['data'] = $this->getData($table[0]);*/
				}
				else {
					if (strpos($table[0],$lb_prefix) !== false)
					{
						$value[] = $table[0];
						/*$this->tables[$i]['name'] = $table[0];
						$this->tables[$i]['create'] = $this->getColumns($table[0]);
						$this->tables[$i]['data'] = $this->getData($table[0]);*/
					}
				}
                $i++;
            }
            unset($stmt);
            unset($tbs);
            unset($i);

            return $value;
        } catch (PDOException $e) {
            $this->handler = null;
            $this->error[] = $e->getMessage();
            return false;
        }

	}
	     /* Get the list of Columns
     * @uses Private use
     */
    private function getColumns($tableName){
        try {
            $stmt = $this->handler->query('SHOW CREATE TABLE '.$tableName);
            $q = $stmt->fetchAll();
            $q[0][1] = preg_replace("/AUTO_INCREMENT=[\w]*./", '', $q[0][1]);
            return $q[0][1];
        } catch (PDOException $e){
            $this->handler = null;
            $this->error[] = $e->getMessage();
            return false;
        }
    }

    /**
     *
     * Get the insert data of tables
     * @uses Private use
     */
    private function getData($tableName){
		if (strpos($tableName,'_session')) {   // RRG 19/03/2018 exclusion des données table #__session
			$data = '';
			return $data;
		} else {
			try {
					$stmt = $this->handler->query('SELECT * FROM '.$tableName);
					$q = $stmt->fetchAll(PDO::FETCH_ASSOC);
					$data = '';
					foreach ($q as $pieces){
						foreach($pieces as &$value){
							//$value = htmlspecialchars(addslashes($value)); 31/08/2016 suppression htmlspecialchars
							$value = addslashes($value);
							$value = str_replace("\n","\\n",$value);
						}
						$data .= 'INSERT INTO '. $tableName . ' VALUES (\'' . implode('\',\'', $pieces) . '\');'."\n";
					}
					return $data;
				} catch (PDOException $e){
					$this->handler = null;
					$this->error[] = $e->getMessage();
					return false;
				}
		}
	}


	function _DumpTable($table, $fp, $compress)
	{
		$value = '';
		$this->handler->query('LOCK TABLES ' . $table . ' WRITE');
		if ($this->create_tables)
		{
			if ($this->comments)
			{
				$value .= '--' . MSX_NL;
				$value .= '-- Table structure for table `' . $table . '`' . MSX_NL;
				$value .= '-- ' . MSX_NL . MSX_NL;
			}
			if ($this->drop_tables)
			{
				$value .= 'DROP TABLE IF EXISTS `' . $table . '`;' . MSX_NL;
			}
			if (!$result = $this->getColumns($table))
			{
				return false;
			}
			$value .= $result.';';
			$value .= MSX_NL . MSX_NL;
		}
		//if (!$this->struct_only)
		$struct_only = $this->struct_only;
		if ($struct_only == 0)
		{
			if ($this->comments)
			{
				$value .= '--' . MSX_NL;
				$value .= '-- Dumping data for table `' . $table . '`' . MSX_NL;
				$value .= '--' . MSX_NL . MSX_NL;
			}
			$data = $this->getData($table);
			if (!$data=='')
			{
			$value .="/*!40000 ALTER TABLE `$table` DISABLE KEYS */;".MSX_NL;

			if ($this->locks)
			{
				$value .= 'LOCK TABLES ' . $table . ' WRITE;' . MSX_NL;
			}			
			$value .= $data;
			if ($this->locks)
			{
				$value .= 'UNLOCK TABLES ;' . MSX_NL;
			}
			$value .= "/*!40000 ALTER TABLE `$table` ENABLE KEYS */;".MSX_NL;
			}
		}
		$value .= MSX_NL . MSX_NL;
		if ($fp)
		{
			if ($compress) gzwrite($fp, $value);
			else fwrite ($fp, $value);
			$value = true;
		}
		$this->handler->query('UNLOCK TABLES');
		return $value;
	}


	function _Retrieve($fp, $compress)
	{
		$value = '';
		$this->host = $this->server;
		$this->driver='mysql';
        if($this->host=='localhost'){
            $this->host = '127.0.0.1';
        }
        $this->dsn = $this->driver.':host='.$this->host.';dbname='.$this->database;

		if ($this->Connect($this->dsn,$this->username,$this->password)==false)
		{
			return false;
		}
		/** 
		 * Make sure any results we retrieve or commands we send use the same 
		 * charset as the database:
		 */
		$db_charset = $this->handler->query("SHOW VARIABLES LIKE 'character_set_database';"); 
		$charset_row = $db_charset->fetch(PDO::FETCH_ASSOC);
		//$value = $charset_row['Value'];
		//$charset_row = mysql_fetch_assoc( $db_charset );
		//$this->handler->query( "SET NAMES '" . $charset_row['Value'] . "'" );
		$this->handler->query( "SET NAMES 'utf8'" );
		//$value=(string)$db_charset;
			if ($fp)
			{
				if ($compress) gzwrite($fp, '-- ' . 'charset=' . $charset_row['Value'] .MSX_NL);
				else fwrite ($fp, '-- ' . 'charset=' . $charset_row['Value'] .MSX_NL);
			}
		/*if ($this->Connect($this->dsn .';charset=' . $charset_row['Value'],$this->username,$this->password)==false)
		{
			return false;
		}*/
		
		if ($this->comments)
		{
			$value .= '--' . MSX_NL;
			$value .= '-- MySQL database dump' . MSX_NL;
			$value .= '-- Created by MySQL_Backup class, ver. ' . MSX_VERSION . MSX_NL;
			$value .= '--' . MSX_NL;
			$value .= '-- Host: ' . $this->server . MSX_NL;
			$value .= '-- Generated: ' . date('M j, Y') . ' at ' . date('H:i') . MSX_NL;
			//$value .= '-- MySQL version: ' . mysql_get_server_info() . MSX_NL;
			$value .= '-- MySQL version: ' . $this->handler->getAttribute(constant("PDO::ATTR_SERVER_VERSION")) . MSX_NL;
			$value .= '-- PHP version: ' . phpversion() . MSX_NL;
			if (!empty($this->database))
			{
				$value .= '--' . MSX_NL;
				$value .= '-- Database: `' . $this->database . '`' . MSX_NL;
			}
			// Insert option Foreign Key
			$foreign_key =$this->foreign_key;
			$value_key ='';
			if ($foreign_key == 1) {
				$value .= '--' . MSX_NL;
				$value .= 'SET FOREIGN_KEY_CHECKS=0;' . MSX_NL;
				$value .= '--' . MSX_NL;
			}
			// End Insert option Foreign Key
			$value .= '/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;' . MSX_NL;
			$value .= '/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;' . MSX_NL;
			$value .= '/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;' . MSX_NL;
			$value .= '/*!40101 SET NAMES utf8 */;' . MSX_NL;
			$value .= '--' . MSX_NL . MSX_NL . MSX_NL;
			if ($fp)
			{
				if ($compress) gzwrite($fp, $value);
				else fwrite ($fp, $value);
				unset($value);
				$value = '';
			}
		}
		$dblb = JFactory::getDBO();
		$config = JFactory::getConfig();
		$lb_prefix     = $config->get('dbprefix');
		if (!($tables = $this->_GetTables($lb_prefix)))
		{
			return false;
		}
		foreach ($tables as $table)
		{
			if (!($table_dump = $this->_DumpTable($table,$fp,$compress)))
			{
				return false;
			}
			if ($fp)
			{
				$value = true;
			}
			else
			{
				$value .= $table_dump;
			}
		}
		// Insert option Foreign Key
		$foreign_key =$this->foreign_key;
		$valuekey ='';
		if ($foreign_key == 1) {
			$valuekey .= MSX_NL .'--' . MSX_NL;
			$valuekey .= 'SET FOREIGN_KEY_CHECKS=1;' . MSX_NL;
			$valuekey .= '--' . MSX_NL;
			$valuekey .= '/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;' . MSX_NL;
			$valuekey .= '/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;' . MSX_NL;
			$valuekey .= '/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;' . MSX_NL;
			if ($fp)
			{
				if ($compress) gzwrite($fp, $valuekey);
				else fwrite ($fp, $valuekey);
				unset($valuekey);
				$valuekey = '';
			}

		}
		// End Insert option Foreign Key 
		return $value;
	}

	function _OpenFile($fname, $task, $compress)
	{
		if ($task != MSX_APPEND && $task != MSX_SAVE && $task != MSX_DOWNLOAD)
		{
			$this->error = 'Tried to open file in wrong task.';
			return false;
		}
		
		$mode = 'w';
		if ($task == MSX_APPEND && file_exists($fname))
		{
			$mode = 'a';
		}
		
		if ($compress) $fp = gzopen($fname, $mode . '9');
		else $fp = fopen($fname, $mode);

		if (!$fp)
		{
			$this->error = 'Can\'t create the output file.' . $fname ;
			return false;
		}
		return $fp;
	}

	function _CloseFile($fp, $compress)
	{
		if ($compress)
		{
			return gzclose($fp);
		}
		else
		{
			return fclose($fp);
		}
	}

	function _DownloadFile($fname, $dname)
	{
		$fp = fopen($fname, 'rb');
		if (!$fp)
		{
			$this->error = 'Can\'t open temporary file.';
			return false;
		}
		header('Content-disposition: filename=' . $dname);
		header('Content-type: application/octetstream');
		header('Pragma: no-cache');
		header('Expires: 0');
		while ($value = fread($fp,8192))
		{
			echo $value;
			unset ($value);
		}
		fclose($fp);
		unlink ($fname);

		return true;
	}

}
?>