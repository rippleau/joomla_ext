<?php
/**
* @version		3.0
* @copyright	Copyright (C) 2007-2012 Stephen Brandon
* @license		GNU/GPL
*/

// Check to ensure this file is included in Joomla!
defined('JPATH_BASE') or die;

jimport('joomla.form.formfield');

class JFormFieldGeoipcheck extends JFormField
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	protected $type = 'Geoipcheck';

	/**
	 * Method to get the field input markup.
	 *
	 * @return	string	The field input markup.
	 * @since	1.6
	 */
	protected function getInput() {
		
		$files = $this->geoIPFolders();
		$foundcountry = $foundlitecity = $foundcity = $foundcountrylite2 = $foundcitylite2 = $found = false;
		$messages = array();
		
		foreach ($files as $file) {
			$proposed_file = JPATH_SITE.'/'.$file.'GeoIP.dat';
			$country = is_file($proposed_file) && is_readable($proposed_file);
			$proposed_file = JPATH_SITE.'/'.$file.'GeoLiteCity.dat';
			$litecity = is_file($proposed_file) && is_readable($proposed_file);
			$proposed_file = JPATH_SITE.'/'.$file.'GeoIPCity.dat';
			$city = is_file($proposed_file) && is_readable($proposed_file);
			$proposed_file = JPATH_SITE.'/'.$file.'GeoLite2-Country.mmdb';
			$countrylite2 = is_file($proposed_file) && is_readable($proposed_file);
			$proposed_file = JPATH_SITE.'/'.$file.'GeoLite2-City.mmdb';
			$citylite2 = is_file($proposed_file) && is_readable($proposed_file);
			
			if ($country && !$foundcountry) {
				$age = intval((time() - filemtime(JPATH_SITE.'/'.$file.'GeoIP.dat'))/(24*60*60));
				if ($age > 30) $age = "<span style='color:red;'>" . JText::sprintf("MM_GEOIP_PLEASE_UPDATE", $age,
					"<a href='http://www.maxmind.com/app/ip-location' target='_blank'>MaxMind</a>") . "</span>";
				else $age = "";
				$messages[] = $file . JText::_("MM_GEOIP_COUNTRY_CHECK_FOUND") . " $age";
				$foundcountry = true;
			}
			if ($litecity && !$foundlitecity) {
				$age = intval((time() - filemtime(JPATH_SITE.'/'.$file.'GeoLiteCity.dat'))/(24*60*60));
				if ($age > 30) $age = "<span style='color:red;'>" . JText::sprintf("MM_GEOIP_PLEASE_UPDATE", $age,
					"<a href='https://dev.maxmind.com/geoip/geoip2/geolite2/' target='_blank'>MaxMind</a>") . "</span>";
				else $age = "";
				$messages[] = $file . JText::_("MM_GEOIP_LITECITY_CHECK_FOUND") . " $age";
				$foundlitecity = true;
			}
			if ($city && !$foundcity) {
				$age = intval((time() - filemtime(JPATH_SITE.'/'.$file.'GeoIPCity.dat'))/(24*60*60));
				if ($age > 30) $age = "<span style='color:red;'>" . JText::sprintf("MM_GEOIP_PLEASE_UPDATE", $age,
					"<a href='https://dev.maxmind.com/geoip/geoip2/geolite2/' target='_blank'>MaxMind</a>") . "</span>";
				else $age = "";
				$messages[] = $file . JText::_("MM_GEOIP_CITY_CHECK_FOUND") . " $age";
				$foundcity = true;
			}
			if ($countrylite2 && !$foundcountrylite2) {
				$age = intval((time() - filemtime(JPATH_SITE.'/'.$file.'GeoLite2-Country.mmdb'))/(24*60*60));
				if ($age > 30) $age = "<span style='color:red;'>" . JText::sprintf("MM_GEOIP_PLEASE_UPDATE", $age,
					"<a href='https://dev.maxmind.com/geoip/geoip2/geolite2/' target='_blank'>MaxMind</a>") . "</span>";
				else $age = "";
				$messages[] = $file . JText::_("MM_GEOIP_COUNTRYLITE2_CHECK_FOUND") . " $age";
				$foundcountrylite2 = true;
			}
			if ($citylite2 && !$foundcitylite2) {
				$age = intval((time() - filemtime(JPATH_SITE.'/'.$file.'GeoLite2-City.mmdb'))/(24*60*60));
				if ($age > 30) $age = "<span style='color:red;'>" . JText::sprintf("MM_GEOIP_PLEASE_UPDATE", $age,
					"<a href='https://dev.maxmind.com/geoip/geoip2/geolite2/' target='_blank'>MaxMind</a>") . "</span>";
				else $age = "";
				$messages[] = $file . JText::_("MM_GEOIP_CITYLITE2_CHECK_FOUND") . " $age";
				$foundcitylite2 = true;
			}
			
		}
		if ($foundcountry || $foundlitecity || $foundcity || $foundcountrylite2 || $foundcitylite2) {
			return "<b>".implode("<br/>",$messages).'</b>
			<br />' . JText::sprintf("MM_GEOIP_KEEP_UPTODATE",
				'<a href="https://dev.maxmind.com/geoip/geoip2/geolite2/" target="_blank">MaxMind</a>');
		}
		return JText::_('GEOIP_DOWNLOAD_HELPTEXT');
	}
	
	function geoIPFolders() {
		return array(
			'administrator/components/com_chameleon/geoip/',
			"geoip/",
			"GeoIP/",
			"geoIP/",
			"GEOIP/",
			"GEO IP/",
			"",
			"geo_ip/",
			"geo_IP/",
			"Geo_IP/"
			);
		
	}
	
}