<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * JomGenius classes
 * 
 * @package		JomGenius
 * @version		1
 * @license		GNU/GPL
 * @copyright	Copyright (C) 2010-2015 Brandon IT Consulting. All rights reserved.
 */

class JomGeniusClassFlexicontent extends JomGeniusParent {
	
	var $Itemid;
	var $view;
	var $option;
	var $category_id;
	var $layout;
	var $task;
	var $id;
	var $cid;
	var $clayout;
	var $flexi_callview;
	
	function __construct() {
		$jinput				= JFactory::getApplication()->input; // j3.0
		
		$this->Itemid			= $jinput->get('Itemid');
		$this->view				= $jinput->get('view','','WORD');
		$this->option			= $jinput->get('option');
		$this->category_id		= $jinput->get('category_id');
		$this->layout			= $jinput->get('layout');
		$this->task				= $jinput->get('task');
		$this->id				= $jinput->get('id', null, '');// 3rd null is the filter, forces to default that can handle arrays.
		$this->cid				= $jinput->getString('cid');
		$this->cids				= $jinput->get('cids', null, '');
		$this->clayout			= $jinput->getString('clayout');
		$this->flexi_callview	= $jinput->getString('flexi_callview');
		$this->authorid			= $jinput->getInt('authorid');
	}
	
	function shouldInstantiate() {
		return true;
		// we allow instantiation even if we are not viewing a com_flexicontent page,
		// basically just for convenience. I don't think there's anything that we can
		// query that would make sense if we are NOT on a FC page, but we'll instantiate anyway.
	}

	
	/* particular methods for this component */
	
	/**
	 * A generic function that knows how to get lots of different info about the current article, category or section.
	 */
	function info( $type ) {
		$jinput				= JFactory::getApplication()->input; // j3.0
		
		// some special handling, that need not hit the database
		switch( $type ) {
			case 'categoryids' :
			case 'category_ids': return $this->categoryIds();
			case 'categoryid'  :
			case 'category_id' : return $this->categoryId();
			case 'pagetype'    :
			case 'page_type'   : return $this->pageType();
			case 'ispreview'   :
			case 'is_preview'  : return ($jinput->get('preview') == '1');
			case 'itemid'	   :
			case 'item_id'	   : return $this->check('pagetype starts with item') ? $jinput->getInt('id') : '';
			default:
		}
		
		if ( $this->option != 'com_flexicontent' ) return null;
		// from here on, only serves info relating to com_flexicontent pages that we are on now.
		
		$item_id = $this->info( 'item_id' );
		
		if ( $type == 'item_tags' or $type == 'itemtags' ) {
			return $this->tagsForItem( $item_id );
		}

		// everything else requires the database
		if ( $this->view == 'item' ) {
			$row = $this->_infoForItemId( $item_id );
		} else if ( $this->view == 'category') {
			$row = $this->_infoForCategoryId( (int)$this->cid );
		}
		
		if ( $type == 'ancestor_category_ids' and $this->info('pagetype') == 'categories' and is_array($this->cids)) {
			$cats = array();
			foreach ($this->cids as $cid) {
				$row = $this->_infoForCategoryId((int)$cid);
				if ($row) {
					$cats = array_merge($cats,$row->ancestor_category_ids);
				}
			}
			return array_unique($cats);
		}
		
		switch( $type ) {
			case 'item_id':
			case 'item_title':
			case 'item_alias':
			case 'item_hits':
			case 'item_version':
			case 'item_created_by':
			case 'item_modified_by':
			case 'item_introtext':
			case 'item_fulltext':

			case 'item_created':
			case 'item_modified':
			case 'item_publishup':
			case 'item_publishdown':
			case 'item_metakeywords':
			case 'item_metadescription':
			case 'item_created_age':
			case 'item_modified_age':
			case 'item_featured':
			case 'item_language':

			case 'category_id':
			case 'category_title':
			case 'category_alias':
			case 'category_description':
			case 'category_language':
			case 'category_note':
			case 'ancestor_category_titles':
			case 'ancestor_category_ids':
			
				return @$row->$type;
			default:
		}
		// are there some more things that we might need to calculate?
		return null;
	}
	
	function tagsForItem( $id ) {
		if (!$id) return null;
		
		$db			= JFactory::getDbo();		
		$query = 'SELECT t.name' .
				' FROM #__flexicontent_tags t, #__flexicontent_tags_item_relations r' .
				' WHERE r.itemid = '.(int) $id . ' AND r.tid = t.id AND t.published = 1';
		$db->setQuery($query);
		$tags = $db->loadColumn();
		
		if ( !$tags ) {
			return array();
		}
		return $tags;
	}
	
	function arbitraryCatIdsForItem( $id ) {
		$db			= JFactory::getDbo();		
		$query = 'SELECT r.`catid` from #__flexicontent_cats_item_relations r' .
				' WHERE r.`itemid` = '.(int) $id ;
		$db->setQuery($query);
		$catids = $db->loadColumn();
		
		if ( !$catids ) {
			return array();
		}
		return $catids;
	}
		
	
	function pageType() {
		if ( $this->option != 'com_flexicontent' ) return null;
		$jinput				= JFactory::getApplication()->input; // j3.0
		
		switch ( $this->view ) {
			case 'search':
				if ($jinput->getString('q',null) !== null) return 'search.results';
				return 'search';
			case 'item':
				if ($this->task == 'add') return 'item.add';
				if ($this->task == 'edit') return 'item.edit';
				return 'item.view';
			case 'flexicontent':
				return 'directory';
			case 'tags':
				return 'tagged';
			case 'category':
				if ( $this->authorid ) return 'author';
				if ( $jinput->getString('tagid',null) !== null ) return 'tagged';
				if ( $this->layout == 'favs' ) return 'favourites';
				if ( $this->layout == 'myitems' ) return 'myitems';
				if ( is_array($this->cids) and count($this->cids) ) return 'categories';
				return 'category';
		}

		return '';
	}
		
	/* returns the category id of the list, or the item being displayed.
	 * If the list: this is taken from the URL or menu item
	 * If the item: if a category id was in the URL then this is used. Otherwise,
	 *  the category of the item is used.
	 * For items, any additional categories that the item was added to manually
	 * (i.e. not part of the hierarchy) are also added.
	 */
	function categoryIds() {
		if ( $this->option != 'com_flexicontent' ) return null;
		$id = $this->info('item_id');
		
		$pagetype = $this->info('pagetype');
		
		// if the page is set up via a menu item to show items from 1 or more categories,
		// use that list of categories.
		if ( $pagetype == 'categories' ) {
			return $this->cids;
		}
		
		$category_id = $this->categoryId(); // basic id

		if ($this->check('pagetype starts with item')) {
			$extras = $this->arbitraryCatIdsForItem($this->info('item_id'));
			if ( !in_array( $category_id, $extras ) ) {
				$extras[] = $category_id;
			}
			return $extras;
		}
		return array( $category_id );
	}

	/* just get the main category that an item is part of. Don't get any other arbitrary ones. */
	
	function categoryId() {
		if ( $this->option != 'com_flexicontent' ) return null;
		$id = $this->info('item_id');
		
		$category_id = 0;
		
		if ( $this->view == 'category' or $this->view == 'item' ) {
			/* category list and item pages normally have a 'cid' parameter with the category in it */
			$category_id = (int)$this->cid;
		}
		
		if ( $category_id == 0 && $this->view == "item" ) {
			/* if it's an item page without the cid mentioned in the url */
			$row = $this->_infoForItemId( $id );
			$category_id = (int)@$row->category_id;
		}

		return $category_id;
	}
	
	
	function _infoForItemId( $id ) {
		static $rows = array();
		if ( is_array($id) ) {
			return;
		}

		if ( !array_key_exists( $id, $rows ) ) {

			$db			= JFactory::getDbo();
			$query		= $db->getQuery(true); 

			$nullDate	= $db->Quote( $db->getNullDate() );
			$my_id		= $db->Quote( $db->escape( (int)$id ) );
			$jnow		= JFactory::getDate();
			
			if ( version_compare( JVERSION, '2.5', 'l' ) )
			{
				$now	= $db->Quote( $db->escape( $jnow->toMySQL() ) );			
			}
			else
			{
				$now	= $db->Quote( $db->escape( $jnow->toSQL() ) );			
			}
			
			
			$query->select("DISTINCT

				a.id as item_id,
				a.title as item_title,
				a.alias as item_alias,
				a.language as item_language,
				a.featured as item_featured,
				a.hits as item_hits,
				a.version as item_version,
				a.created_by as item_created_by,
				a.modified_by as item_modified_by,
				a.introtext as item_introtext,
				a.fulltext as item_fulltext,
				a.created as item_created,
				a.modified as item_modified,
				a.publish_up as item_publishup,
				a.publish_down as item_publishdown,
				a.metakey as item_metakeywords,
				a.metadesc as item_metadescription,
				floor(time_to_sec(timediff(now(),a.created))/60) as item_created_age,
				floor(time_to_sec(timediff(now(),a.modified))/60) as item_modified_age,
			
				a.catid as category_id,
				cat1.title as category_title,
				cat1.alias as category_alias,
				cat1.language as category_language,
				cat1.description as category_description,
				cat1.note as category_note,
			
				cat1.title as ct1,
				cat1.id as ci1,
				cat2.title as ct2,
				cat2.id as ci2,
				cat3.title as ct3,
				cat3.id as ci3,
				cat4.title as ct4,
				cat4.id as ci4,
				cat5.title as ct5,
				cat5.id as ci5,
				cat6.title as ct6,
				cat6.id as ci6,
				cat7.title as ct7,
				cat7.id as ci7,
				cat8.title as ct8,
				cat8.id as ci8
				");
			$query->from("`#__content` a");
			$query->leftJoin( "`#__categories` cat1 ON a.catid = cat1.id ")
				->leftJoin( "`#__categories` cat2 ON cat1.parent_id = cat2.id ")
				->leftJoin( "`#__categories` cat3 ON cat2.parent_id = cat3.id ")
				->leftJoin( "`#__categories` cat4 ON cat3.parent_id = cat4.id ")
				->leftJoin( "`#__categories` cat5 ON cat4.parent_id = cat5.id ")
				->leftJoin( "`#__categories` cat6 ON cat5.parent_id = cat6.id ")
				->leftJoin( "`#__categories` cat7 ON cat6.parent_id = cat7.id ")
				->leftJoin( "`#__categories` cat8 ON cat7.parent_id = cat8.id ")
				;
				
			$query->where( "a.id = $my_id" )
				->where( "a.state = 1" )
			    ->where( "( a.publish_up = $nullDate OR a.publish_up <= $now )" )
		    	->where( "( a.publish_down = $nullDate OR a.publish_down >= $now )" );
			
			$db->setQuery( $query, 0, 1 );
			$row		= $db->loadObject();
			if ($row != null) {
				$cat_titles = array();
				$cat_ids	= array();
				for($i = 1; $i <= 8; $i++ ) {
					$ct = "ct$i";
					$ci = "ci$i";
					if ( $row->$ct != '' and $row->$ci != 1) $cat_titles[] = $row->$ct;
					if ( $row->$ci != '' and $row->$ci != 1) $cat_ids[] = $row->$ci;
				}
				$row->ancestor_category_titles = $cat_titles;
				$row->ancestor_category_ids = $cat_ids;
				$rows[$id]	= $row;
			} else {
				return null;
			}
		}
		return @$rows[$id];
	}

	function _infoForCategoryId( $id ) {
		static $rows = array();
		if ( is_array($id) ) {
			return;
		}
		
		if ( !array_key_exists( $id, $rows ) ) {
			$db			= JFactory::getDbo();
			$query		= $db->getQuery(true); 

			$nullDate	= $db->Quote( $db->getNullDate() );
			$my_id		= $db->Quote( $db->escape( (int)$id ) );			
			
			$query->select("DISTINCT
				cat1.id as category_id,
				cat1.title as category_title,
				cat1.alias as category_alias,
				cat1.language as category_language,
				cat1.description as category_description,
				cat1.note as category_note,
			
				cat1.title as ct1,
				cat1.id as ci1,
				cat2.title as ct2,
				cat2.id as ci2,
				cat3.title as ct3,
				cat3.id as ci3,
				cat4.title as ct4,
				cat4.id as ci4,
				cat5.title as ct5,
				cat5.id as ci5,
				cat6.title as ct6,
				cat6.id as ci6,
				cat7.title as ct7,
				cat7.id as ci7,
				cat8.title as ct8,
				cat8.id as ci8
				");

			$query->from("`#__categories` cat1");
			$query->leftJoin( "`#__categories` cat2 ON cat1.parent_id = cat2.id" )
				->leftJoin( "`#__categories` cat3 ON cat2.parent_id = cat3.id" )
				->leftJoin( "`#__categories` cat4 ON cat3.parent_id = cat4.id" )
				->leftJoin( "`#__categories` cat5 ON cat4.parent_id = cat5.id" )
				->leftJoin( "`#__categories` cat6 ON cat5.parent_id = cat6.id" )
				->leftJoin( "`#__categories` cat7 ON cat6.parent_id = cat7.id" )
				->leftJoin( "`#__categories` cat8 ON cat7.parent_id = cat8.id" )
				;
				
			$query->where( "cat1.id = $my_id" )
			 	->where( "cat1.published = 1");

			$db->setQuery( $query, 0, 1 );
			$row		= $db->loadObject();
			if ($row != null) {
				$cat_titles = array();
				$cat_ids	= array();
				for($i = 1; $i <= 8; $i++ ) {
					$ct = "ct$i";
					$ci = "ci$i";
					if ( $row->$ct != '' and $row->$ci != 1) $cat_titles[] = $row->$ct;
					if ( $row->$ci != '' and $row->$ci != 1) $cat_ids[] = $row->$ci;
				}
				$row->ancestor_category_titles = $cat_titles;
				$row->ancestor_category_ids = $cat_ids;

				$rows[$id]	= $row;
			} else {
				return null;
			}
		}
		return @$rows[$id];
	}
	

}